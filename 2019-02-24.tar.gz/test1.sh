#!/bin/bash
df -h >`date +%F`.log
