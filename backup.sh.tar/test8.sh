#!/bin/bash
lbakdir=/var/mysql
remote_bakdir=192.168.253.215:/backup
d1=$(date +%w)
d2=$(date +%d)
exec 1> /tmp/mysqlbak.log 2>/tmp/mysqlbak.err
echo "mysql back start at `date`."
mysqldump -uroot -pmysql DJ_app >$lbakdir/discuz.bak.sql.$d1
rsync -az $lbakdir/discuz.bak.sql.$d1 $remote_bakdir/discuz.bak.sql.$d2
if [ "$?" -eq "0" ];then
  echo "mysql back end at `date`."
else
  echo "mysql back faild. `date`."
fi
